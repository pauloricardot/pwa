﻿var VersionCacheName = 'Demo-Final-v1';
var CacheFiles = [
           '/',
           "/Content/badge.png",
           "/Content/plus-3b9086a9.png",
           "/Content/eye-b8d4405c.png",
           "/Content/icon.png",
          '/Content/app.js',
          '/Content/bootstrap.css',
          '/Content/bootstrap.min.css',
          '/Content/Site.css',
          '/fonts/glyphicons-halflings-regular.eot',
          '/fonts/glyphicons-halflings-regular.svg',
          '/fonts/glyphicons-halflings-regular.ttf',
          '/fonts/glyphicons-halflings-regular.woff',
          '/Scripts/jquery-1.10.2.js',
          '/Scripts/bootstrap.js',
          '/Scripts/modernizr-2.6.2.js',
          '/android-chrome-144x144.png',
          '/manifest.json',
          '/favicon.ico',
          '/favicon-32x32.png',
          '/favicon-16x16.png'

];



//Installing
//Pre-cache App Shell
self.addEventListener('install', function (event) {
    console.log('form sw: install', event);
    self.skipWaiting();
    event.waitUntil(
        caches.open(VersionCacheName)
        .then(function (cache) {
            return cache.addAll(CacheFiles);
        })
    );
});

//Activating
//Clean up
self.addEventListener('activate', function (event) {
    console.log('from sw: activate state', event);
    self.clients.claim();

    event.waitUntil(
    caches.keys()
      .then(function (cacheKeys) {
          var deletePromises = [];
          for (var i = 0; i < cacheKeys.length; i++) {
              if (cacheKeys[i] != VersionCacheName) {
                  deletePromises.push(caches.delete(cacheKeys[i]));
              }
          }
          return Promise.all(deletePromises);
      })
  );
});

//Event listeners one activated
self.addEventListener('fetch', function (event) {
    //if (event.request.mode === 'navigate') {
    //    event.respondWith(fetch('/pwa'));

    //    // Immediately start downloading the actual resource.
    //    fetch(event.request.url);
    //}
    //console.log("pedidos da rede");
    var requestUrl = new URL(event.request.url);
    var requestPath = requestUrl.pathname;
    var fileName = requestPath.substring(requestPath.lastIndexOf('/') + 1);

    if (requestPath  || fileName == "sw.js") {
        //Network Only Strategy
        event.respondWith(fetch(event.request));
    } else if (requestPath) {
        //Network First then Offline Strategy
        event.respondWith(networkFirstStrategy(event.request));
    } else {
        //Offline First then Network Strategy
        event.respondWith(cacheFirstStrategy(event.request));
    }
});
//Caching Strategies
function cacheFirstStrategy(request) {
    return caches.match(request).then(function (cacheResponse) {
        return cacheResponse || fetchRequestAndCache(request);
    });
}
//verifica qual o estado da rede 
function networkFirstStrategy(request) {
    return fetchRequestAndCache(request).catch(function (response) {
        return caches.match(request);
    })
}

//Fetch Request And Cache
function fetchRequestAndCache(request) {
    return fetch(request).then(function (networkResponse) {
        caches.open(getCacheName(request)).then(function (cache) {
            cache.put(request, networkResponse);
        })
        return networkResponse.clone();
    });
}

//retorna o local das pagina em cache 
function getCacheName(request) {
    var requestUrl = new URL(request.url);
    var requestPath = requestUrl.pathname;

    //if (requestPath == imagePath) {
    //    return CacheImagesName;
    //} else if (requestPath == carPath) {
    //    return CachePagesName;
    //} else {
        return VersionCacheName;
    //}
}

self.addEventListener('push', function (event) {
    console.log('[Service Worker] Push Received.');
    console.log(`[Service Worker] Push had this data: "${event.data.text()}"`);

    var title = "Nova Mensagem";
    var options = {
        renotify: true,
        requireInteraction: true,
        //silent: true,
        body: "mensagem aqui",
        image: "http://spacetechtecnologiaweb.com/img/001.png",
        icon: "\/Content/icon.png",
        badge: "\/android-chrome-144x144.png",
        vibrate: [200, 100, 200, 100, 200, 100, 400],
        tag: "request",
        data: "dados aqui",
        actions: [{
            action: "view",
            title: "Ver Agora",
            icon: "\/Content/eye-b8d4405c.png"
        }, {
            action: "later",
            title: "Adicionar Agora",
            icon: "\/Content/plus-3b9086a9.png"
        }]
    };


    const maxVisibleActions = Notification.maxActions;
    if (maxVisibleActions < 4) {
        options.body = `This notification will only display ` +
          `${maxVisibleActions} actions.`;
    } else {
        options.body = `This notification can display up to ` +
          `${maxVisibleActions} actions.`;
    }

    const notificationPromise = self.registration.showNotification(title, options);
    event.waitUntil(notificationPromise);


});


